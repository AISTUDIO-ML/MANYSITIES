#!/bin/bash
echo "Deploying MANYSITIES backend to aws..."
terraform init
terraform apply -auto-approve
