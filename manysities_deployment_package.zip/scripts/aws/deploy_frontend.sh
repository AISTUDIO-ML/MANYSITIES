#!/bin/bash
echo "Deploying MANYSITIES frontend to aws..."
terraform init
terraform apply -auto-approve
