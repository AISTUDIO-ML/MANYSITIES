#!/bin/bash
echo "Deploying MANYSITIES redis to aws..."
terraform init
terraform apply -auto-approve
