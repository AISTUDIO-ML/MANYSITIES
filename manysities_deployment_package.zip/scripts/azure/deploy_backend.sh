#!/bin/bash
echo "Deploying MANYSITIES backend to azure..."
terraform init
terraform apply -auto-approve
