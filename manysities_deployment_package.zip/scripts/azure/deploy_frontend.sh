#!/bin/bash
echo "Deploying MANYSITIES frontend to azure..."
terraform init
terraform apply -auto-approve
