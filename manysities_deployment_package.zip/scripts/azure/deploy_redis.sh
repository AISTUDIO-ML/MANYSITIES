#!/bin/bash
echo "Deploying MANYSITIES redis to azure..."
terraform init
terraform apply -auto-approve
