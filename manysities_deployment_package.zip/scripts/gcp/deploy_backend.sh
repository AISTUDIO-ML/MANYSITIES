#!/bin/bash
echo "Deploying MANYSITIES backend to gcp..."
terraform init
terraform apply -auto-approve
