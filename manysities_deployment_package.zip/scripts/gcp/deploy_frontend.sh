#!/bin/bash
echo "Deploying MANYSITIES frontend to gcp..."
terraform init
terraform apply -auto-approve
