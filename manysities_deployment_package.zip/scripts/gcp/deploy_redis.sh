#!/bin/bash
echo "Deploying MANYSITIES redis to gcp..."
terraform init
terraform apply -auto-approve
