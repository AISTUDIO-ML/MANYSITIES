# MANYSITIES

Automated deployment of thousands of microsites to capture short-term traffic spikes.
