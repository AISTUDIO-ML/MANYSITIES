import React from "react";

const Dashboard = () => {
  return <div>Welcome to MANYSITIES Dashboard</div>;
};

export default Dashboard;
