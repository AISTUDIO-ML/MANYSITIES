import React from "react";
import Dashboard from "../components/Dashboard";

const Home = () => {
  return (
    <div>
      <h1>MANYSITIES</h1>
      <Dashboard />
    </div>
  );
};

export default Home;
