#!/bin/bash
echo "Deploying MANYSITIES to AWS in production..."

# Load secrets from environment variables
export DB_PASSWORD=${DB_PASSWORD}
export API_KEY=${API_KEY}

# Initialize and apply Terraform
terraform init
terraform apply -auto-approve

echo "Deployment to AWS completed."
